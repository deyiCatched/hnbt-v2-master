// xiaomiAccount.js - 小米商城用户信息提取程序
// 从HTTP请求中提取关键信息并保存到xiaomi-accounts.json

import fs from 'fs';
import readline from 'readline';
import { fileURLToPath } from 'url';
import path from 'path'

/**
 * 从HTTP请求中提取小米商城用户的关键信息
 * @param {string} httpRequest - 完整的HTTP请求字符串
 * @returns {Object} 提取的关键信息对象
 */
function extractXiaomiAccountInfo(httpRequest) {
    try {
        const info = {};
        
        // 解析Cookie中的serviceToken和userId
        const cookieMatch = httpRequest.match(/Cookie:\s*([^\n\r]+)/i);
        if (cookieMatch) {
            const cookieStr = cookieMatch[1];
            const serviceTokenMatch = cookieStr.match(/serviceToken=([^;]+)/);
            const userIdMatch = cookieStr.match(/userId=([^;]+)/);
            
            if (serviceTokenMatch) {
                info.serviceToken = serviceTokenMatch[1];
            }
            if (userIdMatch) {
                info.userId = userIdMatch[1];
            }
        }
        
        // 解析d-id
        const dIdMatch = httpRequest.match(/d-id:\s*([^\n\r]+)/i);
        if (dIdMatch) {
            info.dId = dIdMatch[1].trim();
        }
        
        // 解析d-model
        const dModelMatch = httpRequest.match(/d-model:\s*([^\n\r]+)/i);
        if (dModelMatch) {
            info.dModel = dModelMatch[1].trim();
        }
        
        // 解析sentry-trace
        const sentryTraceMatch = httpRequest.match(/sentry-trace:\s*([^\n\r]+)/i);
        if (sentryTraceMatch) {
            info.sentryTrace = sentryTraceMatch[1].trim();
        }
        
        // 解析baggage
        const baggageMatch = httpRequest.match(/baggage:\s*([^\n\r]+)/i);
        if (baggageMatch) {
            info.baggage = baggageMatch[1].trim();
        }
        
        // 解析请求体中的参数
        const bodyMatch = httpRequest.match(/\[\{\},\{([^}]+)\}\]/);
        if (bodyMatch) {
            try {
                const bodyStr = '[' + bodyMatch[0].slice(1, -1) + ']';
                const bodyData = JSON.parse(bodyStr);
                
                if (bodyData && bodyData[1]) {
                    const params = bodyData[1];
                    info.cateCode = params.cateCode;
                    info.regionId = params.regionId;
                    info.activityCategory = params.activityCategory;
                    info.paymentMode = params.paymentMode;
                }
            } catch (parseError) {
                console.warn('⚠️ 解析请求体失败:', parseError.message);
            }
        }
        
        return info;
        
    } catch (error) {
        console.error('💥 提取账户信息失败:', error.message);
        return null;
    }
}

/**
 * 创建标准格式的xiaomi账户对象
 * @param {Object} extractedInfo - 从HTTP请求中提取的信息
 * @param {string} name - 账户名称
 * @param {string} phone - 手机号
 * @returns {Object} 标准格式的xiaomi账户对象
 */
function createXiaomiAccount(extractedInfo, name, phone) {
    if (!extractedInfo) {
        return null;
    }
    
    return {
        name: name || 'extracted_user',
        phone: phone || 'unknown',
        accId: `xiaomi_acc_${Date.now()}`,
        grabToken: `xiaomi_token_${Date.now()}`,
        uniqueId: Date.now().toString(),
        serviceToken: extractedInfo.serviceToken || '',
        userId: extractedInfo.userId || '',
        dId: extractedInfo.dId || '',
        dModel: extractedInfo.dModel || '',
        sentryTrace: extractedInfo.sentryTrace || '',
        baggage: extractedInfo.baggage || '',
        cateCode: extractedInfo.cateCode || 'B01',
        regionId: extractedInfo.regionId || '10',
        activityCategory: extractedInfo.activityCategory || '100',
        paymentMode: extractedInfo.paymentMode || 'UNIONPAY'
    };
}

/**
 * 将账户信息保存到xiaomi-accounts.json文件
 * @param {Object} accountInfo - 账户信息对象
 * @returns {boolean} 保存是否成功
 */
function saveAccountToFile(accountInfo) {
    try {
        const filename = 'xiaomi-accounts.json';
        let existingAccounts = [];
        
        // 如果文件存在，读取现有账户
        if (fs.existsSync(filename)) {
            const fileContent = fs.readFileSync(filename, 'utf8');
            existingAccounts = JSON.parse(fileContent);
        }
        
        // 确保是数组格式
        if (!Array.isArray(existingAccounts)) {
            existingAccounts = existingAccounts ? [existingAccounts] : [];
        }
        
        // 添加新账户
        existingAccounts.push(accountInfo);
        
        // 保存到文件
        fs.writeFileSync(filename, JSON.stringify(existingAccounts, null, 4), 'utf8');
        
        console.log(`✅ 账户信息已保存到 ${filename}`);
        console.log(`📊 当前账户总数: ${existingAccounts.length}`);
        
        return true;
        
    } catch (error) {
        console.error('💥 保存账户信息失败:', error.message);
        return false;
    }
}

/**
 * 显示提取的关键信息
 * @param {Object} extractedInfo - 提取的信息
 */
function displayExtractedInfo(extractedInfo) {
    console.log('\n📋 提取的关键信息:');
    console.log(`   serviceToken: ${extractedInfo.serviceToken ? '✅ 已提取' : '❌ 未找到'}`);
    console.log(`   userId: ${extractedInfo.userId || '❌ 未找到'}`);
    console.log(`   dId: ${extractedInfo.dId ? '✅ 已提取' : '❌ 未找到'}`);
    console.log(`   dModel: ${extractedInfo.dModel || '❌ 未找到'}`);
    console.log(`   sentryTrace: ${extractedInfo.sentryTrace ? '✅ 已提取' : '❌ 未找到'}`);
    console.log(`   baggage: ${extractedInfo.baggage ? '✅ 已提取' : '❌ 未找到'}`);
    console.log(`   cateCode: ${extractedInfo.cateCode || '❌ 未找到'}`);
    console.log(`   regionId: ${extractedInfo.regionId || '❌ 未找到'}`);
    console.log(`   activityCategory: ${extractedInfo.activityCategory || '❌ 未找到'}`);
    console.log(`   paymentMode: ${extractedInfo.paymentMode || '❌ 未找到'}`);
}

/**
 * 创建交互式输入界面
 * @returns {Promise<Object>} 用户输入的账户信息
 */
async function getUserInput() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    return new Promise((resolve) => {
        console.log('\n🔍 小米商城用户信息提取程序');
        console.log('=====================================');
        console.log('请按以下步骤输入信息：\n');
        
        rl.question('📝 请输入账户名称: ', (name) => {
            rl.question('📱 请输入手机号码: ', (phone) => {
                console.log('\n📄 请粘贴完整的HTTP请求内容（输入完成后按两次回车）:');
                
                let httpRequest = '';
                let emptyLineCount = 0;
                
                rl.on('line', (line) => {
                    if (line.trim() === '') {
                        emptyLineCount++;
                        if (emptyLineCount >= 2) {
                            rl.close();
                            resolve({ name, phone, httpRequest });
                        }
                    } else {
                        emptyLineCount = 0;
                        httpRequest += line + '\n';
                    }
                });
            });
        });
    });
}

/**
 * 主函数：处理用户输入并提取账户信息
 */
async function main() {
    try {
        // 获取用户输入
        const userInput = await getUserInput();
        
        console.log('\n🔍 开始提取账户信息...');
        
        // 提取关键信息
        const extractedInfo = extractXiaomiAccountInfo(userInput.httpRequest);
        if (!extractedInfo) {
            console.error('❌ 提取账户信息失败');
            return;
        }
        
        // 显示提取的信息
        displayExtractedInfo(extractedInfo);
        
        // 创建标准格式的账户对象
        const accountInfo = createXiaomiAccount(extractedInfo, userInput.name, userInput.phone);
        
        console.log('\n📄 生成的账户信息:');
        console.log(JSON.stringify(accountInfo, null, 2));
        
        // 保存到文件
        const saved = saveAccountToFile(accountInfo);
        
        if (saved) {
            console.log('\n🎉 账户信息提取并保存成功！');
        } else {
            console.log('\n❌ 保存失败，请检查文件权限');
        }
        
    } catch (error) {
        console.error('💥 程序执行失败:', error.message);
    }
}

// 如果直接运行此文件，执行主函数
const __filename = fileURLToPath(import.meta.url);
const __basename = path.basename(__filename, '.js');

if (process.argv[1].endsWith(__basename) || process.argv[1] === __filename) {
    main();
}

// 导出函数供其他模块使用
export {
    extractXiaomiAccountInfo,
    createXiaomiAccount,
    saveAccountToFile,
    main
};
